import UIKit

var v1 = "Esto es Swift"
let c1 = 4
var cadena:String = String()
cadena = "hola mundo" + v1
print("el contenido es: \(cadena)")
print("el valor de constante es: \(c1)")
